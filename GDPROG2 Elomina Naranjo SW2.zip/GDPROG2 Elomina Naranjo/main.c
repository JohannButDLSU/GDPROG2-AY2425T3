#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#include "inventory.c"
#include "item.c"
#include "shop.c"

int main(){
    
    runShop();

    return 0;
}