#pragma once

void displayShop(int currentTile, char *shopArea, int *playerArea);

void processShop(char *shopInput, int *currentTile, char *shopArea, int *playerArea, char *inventory);

void runShop();