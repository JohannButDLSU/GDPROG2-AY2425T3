#include "item.h"

void displayItem(char item){
    printf("I AM A %c\n", item);
    printf("[INPUT] : ");
}

void processItem(char item, char *itemInput){
    scanf(" %c", itemInput);
    if (*itemInput == 'q' || *itemInput == 'Q'){
        printf("I got a %c !!\n", item);
    }
}

void runItem(char item){
    char itemInput;
    do{
        displayItem(item);
        processItem(item, &itemInput);
    } while(itemInput != 'q' && itemInput != 'Q');
}