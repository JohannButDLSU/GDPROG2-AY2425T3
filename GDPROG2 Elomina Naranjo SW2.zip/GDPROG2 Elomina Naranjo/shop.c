#include "shop.h"

void displayShop(int currentTile, char *shopArea, int *playerArea){
    printf("\n\n");
    printf("► SHOP ────────────\n");
    printf("\n");
    printf("     ┌═══════┐\n");
    printf("     ├───────┤\n");
    // printf("     │ %s │\n", gacha);
    if (currentTile == 0) printf("     │ GHOST │\n");
    if (currentTile == 1) printf("     │ ALIEN │\n");
    if (currentTile == 2) printf("     │ SQUID │\n"); //IM SORRY MS CANDY
    printf("     ├───────┤\n");
    printf("     └═╤═══╤═┘\n");
    printf("      ╔┴█──┤\n");
    printf("      ╚┬───┤\n");
    printf("       └─│─┘\n");
    printf("       ┌─│─┐\n");
    printf("       │   │\n");
    printf("───────╨───╨───────\n");
    for (int i = 0; i < 3; i++) printf("[%c]", shopArea[i]);
    printf("\n");
    for (int i = 0; i < 3; i++) printf("[%d]", playerArea[i]);
    printf("[shopInput]  : ");
}

void processShop(char *shopInput, int *currentTile, char *shopArea, int *playerArea, char *inventory){
    scanf(" %c", shopInput);
    switch (*shopInput)
    {
        case 'd':
        case 'D':
            if (*currentTile != 2){
                playerArea[*currentTile] = 0;
                (*currentTile) ++;
                playerArea[*currentTile] = 1;
            }
            break;
        case 'a':
        case 'A':
            if (*currentTile != 0){
                playerArea[*currentTile] = 0;
                (*currentTile) --;
                playerArea[*currentTile] = 1;
            }
            break;
        case 'e':
        case 'E':
            runItem(shopArea[*currentTile]);
            for (int i = 0; i < 9; i++){
                if (*(inventory+i) == 'E'){
                    *(inventory+i) = shopArea[*currentTile];
                    i=9;
                }
            }
            break;
        case 'i':
        case 'I':
            printf("\n");
            for (int i=0; i<9; i++){
                printf("[%c]", *(inventory+i));
                if (i % 3 == 0) printf("\n");
            }
            break;
        default:
            break;
    }
}

void runShop(){
    char shopInput = '0';
    // int currentInventorySlot = 0;
    int currentTile = 0;
    char shopArea[3] = {'G', 'A', 'S'};
    int playerArea[3] = {1, 0, 0};
    char inventory[3][3]={
        {'E', 'E', 'E'},
        {'E', 'E', 'E'},
        {'E', 'E', 'E'}
    };

    do{
        displayShop(currentTile, shopArea, playerArea);
        processShop(&shopInput, &currentTile, shopArea, playerArea, *inventory);
    } while(shopInput != '0');

}