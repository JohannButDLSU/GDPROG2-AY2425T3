#pragma once

void displayItem(char item);

void processItem(char item, char *itemInput);

void runItem(char item);